const fs = require('node:fs');

const config = {
    owner: ["6289529546720"],
    name: "Ferris-Chan",
    ownername: 'Ferris', 
    ownername2: 'Mashles',
    image: { url: 'https://i.imgur.com/eZ1h3ZE.jpeg' }, //thumbnail: fs.readFileSync('./image/tambahkan-ft-trus-kasih-nama')
    thumbnail: {
      thumbnailUrl: 'https://i.imgur.com/eZ1h3ZE.jpeg'
      //thumbnail: fs.readFileSync('./image/tambahkan-ft-trus-kasih-nama')
    },
    prefix: [".", "?", "!", "/", "#"], //Tambahin sendiri prefix nya kalo kurang
    wagc: [ "https://chat.whatsapp.com/GCtLukH0pBb9oFstDfWwaE" ],
    wach: 'https://whatsapp.com/channel/0029VbAoNph7Noa7oUkdiN2l', 
    sessions: "sessions",
    groq: {
     api: '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'
    },
    link: {
     tt: "https://www.tiktok.com/@CyberFerrisMC"
    },
    sticker: {
      packname: "BLAXK",
      author: "Ferris~"
    },
   messages: {
      wait: "*( Loading )* Tunggu Sebentar...",
      owner: "*( Denied )* Pergi, kamu bukan ownerku🙄",
      premium: "*( Denied )* Maaf banget, kamu bukan user premium 😔, ⚡30hari/3k|DANA|QRIS|OVO->> +6289529546720",
      group: "*( Denied )* Fitur ini khusus group",
      botAdmin: "*( Denied )* Lu siapa bukan Admin group😒",
      grootbotbup: "*( Denied )* Jadiin watashi admin baru bisa digunakan😖",
   },
   database: "rin-db",
   tz: "Asia/Jakarta"
}

module.exports = config

let file = require.resolve(__filename);
fs.watchFile(file, () => {
   fs.unwatchFile(file);
  delete require.cache[file];
});
